import React from 'react'

const Footer = () => {
  return (
    <p className='text-sm py-2 text-center'>
      &copy; 2023 emrangipsy All rights reserved.
    </p>
  )
}

export default Footer
